<?php 
$conn= new mysqli('localhost','tonybedv_1','20082000h@nh','tonybedv_db')or die("Could not connect to mysql".mysqli_error($con));
 mysqli_set_charset($conn, 'UTF8');