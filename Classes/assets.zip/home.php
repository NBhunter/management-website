<?php include 'db_connect.php' ?>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    color: #ffffff96;
}
</style>

<div class="containe-fluid">

	<div class="row mt-3 ml-3 mr-3">
			<div class="col-lg-12">
    			<div class="card">
    				<div class="card-body">
    				<?php echo "Welcome back ". $_SESSION['login_name']."!"  ?>
    					<hr>	

                             			
    				</div>
    				
    				
    		      </div>
                </div>
	</div>
<hr>

</div>
