<?php include 'db_connect.php' ?>
<style>
	.collapse a{
		text-indent:10px;
	}
	.accordion {
  width: 100%;
  max-width: 360px;
  margin: 30px auto 20px;
  background: #FFF;
  -webkit-border-radius: 4px;
  -moz-border-radius: 4px;
  border-radius: 4px;
}

.accordion .link {
  cursor: pointer;
  display: block;
  padding: 15px 15px 15px 42px;
  color: #4D4D4D;
  font-size: 14px;
  font-weight: 700;
  border-bottom: 1px solid #CCC;
  position: relative;
  -webkit-transition: all 0.4s ease;
  -o-transition: all 0.4s ease;
  transition: all 0.4s ease;
}

.accordion li:last-child .link { border-bottom: 0; }

.accordion li i {
  position: absolute;
  top: 16px;
  left: 12px;
  font-size: 18px;
  color: #595959;
  -webkit-transition: all 0.4s ease;
  -o-transition: all 0.4s ease;
  transition: all 0.4s ease;
}

.accordion li i.fa-chevron-down {
  right: 12px;
  left: auto;
  font-size: 16px;
}

.accordion li.open .link { color: #b63b4d; }

.accordion li.open i { color: #b63b4d; }

.accordion li.open i.fa-chevron-down {
  -webkit-transform: rotate(180deg);
  -ms-transform: rotate(180deg);
  -o-transform: rotate(180deg);
  transform: rotate(180deg);
}

/**
 * Submenu
 -----------------------------*/


.submenu {
  display: none;
  background: #444359;
  font-size: 14px;
}

.submenu li { border-bottom: 1px solid #4b4a5e; }

.submenu a {
  display: block;
  text-decoration: none;
  color: #d9d9d9;
  padding: 12px;
  padding-left: 42px;
  -webkit-transition: all 0.25s ease;
  -o-transition: all 0.25s ease;
  transition: all 0.25s ease;
}

.submenu a:hover {
  background: #b63b4d;
  color: #FFF;
}
</style>
<script>
$(function() {
  var Accordion = function(el, multiple) {
    this.el = el || {};
    this.multiple = multiple || false;

    // Variables privadas
    var links = this.el.find('.link');
    // Evento
    links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
  }

  Accordion.prototype.dropdown = function(e) {
    var $el = e.data.el;
      $this = $(this),
      $next = $this.next();

    $next.slideToggle();
    $this.parent().toggleClass('open');

    if (!e.data.multiple) {
      $el.find('.submenu').not($next).slideUp().parent().removeClass('open');
    };
  } 

  var accordion = new Accordion($('#accordion'), false);
});

	
</script>

<nav id="sidebar" class='mx-lt-5 bg-dark' >
		
		<div class="sidebar-list">
		<?php
		

?>
				<a href="index.php?page=home" class="nav-item nav-home"><span class='icon-field'><i class="fa fa-home"></i></span> <?php echo $_SESSION['login_id'] ?>Home</a>
				<?php if($_SESSION['login_type'] == 1): ?>
				<a href="index.php?page=test" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu đã lập</a>
				<!--<a href="index.php?page=all_applications_receipt" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu thu đã lập</a>-->
				<?php endif; ?>
				<?php if(($_SESSION['login_id'] == 11)): ?>
				<a href="index.php?page=applications_chi" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu chi đã lập</a>
				<!--<a href="index.php?page=all_applications_receipt" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu thu đã lập</a>-->
				<?php endif; ?>
				<?php if($_SESSION['login_id'] == 19): ?>
				<a href="index.php?page=applications_thu" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu thu đã lập</a>
				<!--<a href="index.php?page=all_applications_receipt" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu thu đã lập</a>-->
				<?php endif; ?>
				<?php 
				// var_dump($_SESSION['login_id']);
				$TPs = $conn->query("SELECT * FROM `employee_details` WHERE `user_id`= '".$_SESSION['login_id']."'");
								
				if($TPs->num_rows > 0 ){
					$TPid = $TPs->fetch_assoc();
				}
				if($TPid['department_id'] == 4 || ($_SESSION['login_id'] == 20) || $TPid['type'] ==  1|| $TPid['type'] ==  2): ?>
				<a href="index.php?page=applications_dexuat" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu đề xuất đã lập</a>
				<!--<a href="index.php?page=all_applications_receipt" class="nav-item nav-all_applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span>Phiếu thu đã lập</a>-->
				<?php endif; ?>
				<?php if(($_SESSION['login_id'] == 12)||($_SESSION['login_id'] == 13)||($_SESSION['login_id'] == 14)||($_SESSION['login_id'] == 15)||($_SESSION['login_id'] == 16)||($_SESSION['login_id'] == 17)): ?>
				<a href="index.php?page=applications" class="nav-item nav-applications"><span class='icon-field'><i class="fa fa-list-alt">	</i></span> Phiếu đã lập</a>
				<!--<a href="index.php?page=applications_receipt" class="nav-item nav-applications_receipt"><span class='icon-field'><i class="fa fa-list-alt">	</i></span> Phiếu Thu đã lập</a>-->
				<?php endif; ?>
				
					<ul id="accordion" class="accordion">
					<?php if(($_SESSION['login_id'] == 11)||($_SESSION['login_id'] == 19)||($_SESSION['login_id'] == 14)): ?>
  					<li>
  						  <div class="link"><i class="fa fa-database"></i>Phiếu chi<i class="fa fa-chevron-down"></i></div>
  						  <ul class="submenu">
  						    <li><a href="javascript:void(0)" class="nav-item" id="add_leave_customer"><span class='icon-field'><i class="fa fa-plus"></i></span> Lập phiếu chi khách hàng</a></li>
  						    <li><a href="javascript:void(0)" class="nav-item" id="add_leave_supplier"><span class='icon-field'><i class="fa fa-plus"></i></span> Lập phiếu chi nhà cung cấp</a></li>
   						    <li><a href="javascript:void(0)" class="nav-item" id="add_leave"><span class='icon-field'><i class="fa fa-plus"></i></span> Lập phiếu chi </a></li>
   						 </ul>
  					</li>
					  <li>
  						  <div class="link"><i class="fa fa-database"></i>Phiếu thu<i class="fa fa-chevron-down"></i></div>
  						  <ul class="submenu">
  						    <li><a href="javascript:void(0)" class="nav-item" id="add_receipt_customer"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu thu khách hàng</a></li>
  						    <li><a href="javascript:void(0)" class="nav-item" id="add_receipt_supplier"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu thu nhà cung cấp</a></li>
   						    <li><a href="javascript:void(0)" class="nav-item" id="add_receipt"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu thu</a></li>
   						 </ul>
  					</li>
					  <?php endif; ?>
					  <?php if(isset($_SESSION['details']['type']) && $_SESSION['details']['type'] > 1): ?>
					  <li>
  						  <div class="link" id="add_DeXuat"><i class="fa fa-database"></i>Phiếu Đề xuất</div>
  						  <!-- <ul class="submenu">
  						    <li><a href="javascript:void(0)" class="nav-item" id="add_leave_customer"><span class='icon-field'><i class="fa fa-plus"></i></span> Lập phiếu chi khách hàng</a></li>
  						    <li><a href="javascript:void(0)" class="nav-item" id="add_leave_supplier"><span class='icon-field'><i class="fa fa-plus"></i></span> Lập phiếu chi nhà cung cấp</a></li>
   						    <li><a href="javascript:void(0)" class="nav-item" id="add_leave"><span class='icon-field'><i class="fa fa-plus"></i></span> Lập phiếu chi </a></li>
   						 </ul> -->
  					</li>
				</ul>
				<!-- Lap phieu chi -->
				<!--<a href="javascript:void(0)" class="nav-item" id="add_leave_customer"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu chi khách hàng</a>
				<a href="javascript:void(0)" class="nav-item" id="add_leave_supplier"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu chi nhà cung cấp</a>
				<a href="javascript:void(0)" class="nav-item" id="add_leave"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu chi </a>-->
				<!-- lap phieu thu 
				<a href="javascript:void(0)" class="nav-item" id="add_receipt_customer"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu thu khách hàng</a>
				<a href="javascript:void(0)" class="nav-item" id="add_receipt_supplier"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu thu nhà cung cấp</a>
				<a href="javascript:void(0)" class="nav-item" id="add_receipt"><span class='icon-field'><i class="fa fa-plus">	</i></span> Lập phiếu thu</a>-->
				<!-- tao thong tin khach hang va ncc -->
				<a href="javascript:void(0)" class="nav-item" id="add_customer"><span class='icon-field'><i class="fa fa-plus">	</i></span> Thêm khách hàng</a>
				<a href="javascript:void(0)" class="nav-item" id="add_supplier"><span class='icon-field'><i class="fa fa-plus">	</i></span> Thêm nhà cung cấp</a>
				<?php if(($_SESSION['login_id'] == 11)||($_SESSION['login_id'] == 19)||($_SESSION['login_id'] == 14)): ?>
				<a href="index.php?page=my_applications" class="nav-item nav-my_applications"><span class='icon-field'><i class="fa fa-th-list">	</i></span>Phiếu chi của tôi</a>
				<a href="index.php?page=my_applications_receipt" class="nav-item nav-my_applications_receipt"><span class='icon-field'><i class="fa fa-th-list">	</i></span>Phiếu thu của tôi</a>
				<?php endif;?>
				<a href="index.php?page=my_dexuat" class="nav-item nav-my_applications_receipt"><span class='icon-field'><i class="fa fa-th-list">	</i></span>Phiếu đề xuất của tôi</a>
				<?php endif; ?>
					

				<?php if($_SESSION['login_type'] == 1): ?>
				<a href="index.php?page=leave_type" class="nav-item nav-leave_type"><span class='icon-field'><i class="fa fa-th-list"></i></span> Note Type</a>
				<a href="index.php?page=department" class="nav-item nav-department"><span class='icon-field'><i class="fa fa-list"></i></span> Department</a>
				<a href="index.php?page=position" class="nav-item nav-position"><span class='icon-field'><i class="fa fa-list"></i></span> Position</a>
				<a href="index.php?page=employee" class="nav-item nav-employee"><span class='icon-field'><i class="fa fa-user-friends"></i></span> Employee List</a>
				<a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
				<a href="index.php?page=offer_type" class="nav-item nav-leave_type"><span class='icon-field'><i class="fa fa-th-list"></i></span> Offer Type</a>
				
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav_collapse').click(function(){
		console.log($(this).attr('href'))
		$($(this).attr('href')).collapse()
	})
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
	$('#add_leave_customer').click(function(){
		uni_modal("Phiếu chi Khách Hàng mới","manage_leave_customer.php","mid-large")
	})
	$('#add_leave_supplier').click(function(){
		uni_modal("Phiếu chi nhà cung cấp mới","manage_leave_supplier.php","mid-large")
	})
	$('#add_leave').click(function(){
		uni_modal("New Leave Application","manage_leave.php","mid-large")
	})
	$('#add_customer').click(function(){
		uni_modal("Thêm khách hàng mới","manage_customer.php","mid-large")
	})
	$('#add_supplier').click(function(){
		uni_modal("Thêm nhà cung cấp mới","manage_supplier.php","mid-large")
	})
	$('#add_receipt_customer').click(function(){
		uni_modal("Phiếu Thu khách hàng mới","manage_receipt_customer.php","mid-large")
	})
	$('#add_receipt_supplier').click(function(){
		uni_modal("Phiếu Thu nhà cung cấp mới","manage_receipt_repplier.php","mid-large")
	})
	$('#add_receipt').click(function(){
		uni_modal("Phiếu Thu  mới","manage_receipt.php","mid-large")
	})
	$('#add_DeXuat').click(function(){
		uni_modal("Thêm đề xuất mới","manage_dexuat.php","mid-large")
	})
</script>
